# hello-uniapp

`uni-app`框架示例，一套代码，同时发行到iOS、Android、H5、小程序等多个平台，请使用手机扫码快速体验`uni-app`的强大功能。

<p align="center">
    <a href="https://m3w.cn/uniapp" target="blank">
	    <img src="https://img.cdn.aliyun.dcloud.net.cn/guide/uniapp/barcode-20190131.png"/>
    </a>
</p>

`uni-app`官网文档详见[https://uniapp.dcloud.io](https://uniapp.dcloud.io)

更多uni-app的模板、示例详见[插件市场](https://ext.dcloud.net.cn/)

扫码加入uni-app微信交流群：

<p>
    <img src="https://img.cdn.aliyun.dcloud.net.cn/guide/uniapp/wx-barcode.png" width="250"/>
</p>

